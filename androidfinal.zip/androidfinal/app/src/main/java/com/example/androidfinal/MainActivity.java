package com.example.androidfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {
    Spinner spi;
    ListView lview;
    String []  continent ={"Asia","Europe","North America","South America",};
    ArrayList<classconti> allcontinents = new ArrayList<classconti>();
    ArrayList<classconti> selectedcontinent = new ArrayList<classconti>();
    public static String cname;
    public static int ccases;
    public static int curent;
    public static int cdeath;
    public static int recovered;

    //method used to fill the country data
    public void fillcontinentdata()
    {
        allcontinents.add(new classconti("Asia","China",82345,4632,959,77207));
        allcontinents.add(new classconti("Asia","Japan",11950,299,10227,1424));
        allcontinents.add(new classconti("Asia","India",21370,681,16319,4370));
        allcontinents.add(new classconti("Asia","South Korea",10702,240,2051,8233));
        allcontinents.add(new classconti("Europe","UK",133456,18100,115051,22567));
        allcontinents.add(new classconti("Europe","France",159315,21340,79880,40657));
        allcontinents.add(new classconti("Europe","Germany",150234,5315,99400,45560));
        allcontinents.add(new classconti("Europe","Spain",208455,21717,107345,85912));
        allcontinents.add(new classconti("Europe","Italy",187652,25085,107668,545376));
        allcontinents.add(new classconti("North America","Canada",40190,2005,24230,13789));
        allcontinents.add(new classconti("North America","USA",848779,47230,717456,84723));
        allcontinents.add(new classconti("North America","Mexico",10592,970,6947,2627));
        allcontinents.add(new classconti("South America","Brazil",40190,2005,24230,13789));
        allcontinents.add(new classconti("South America","Peru",40190,2005,24230,13789));


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spi=findViewById(R.id.spinnersp);
        lview=findViewById(R.id.listviewlv);
        fillcontinentdata();

        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,continent);
        aa.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spi.setAdapter(aa);
        spi.setOnItemSelectedListener(this);

    }

    //when an item is selected
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
    {
        selectedcontinent.clear();
        String cr = continent[i];
        for (int j=0; j<allcontinents.size(); j++)
            if (allcontinents.get(j).getContinent().equals(cr))
                selectedcontinent.add(allcontinents.get(j));
            lview.setAdapter(new classcontiadapter(selectedcontinent, this));
    }

    //when nothing is selected on screen
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        cname = selectedcontinent.get(i).getCountry();
        curent = selectedcontinent.get(i).getAllCases();
        ccases = selectedcontinent.get(i).getActiveCases();
        cdeath = selectedcontinent.get(i).getDeath();
        recovered = selectedcontinent.get(i).getRecovered();
        Intent intent = new Intent(this,country_details.class);
        startActivity(intent);
    }
}
