package com.example.androidfinal;

public class classconti {
    String continent;
    String country;
    int allcases;
    int death;
    int activecases;
    int recovered;

    //constructor for the above content
    public classconti(String continent, String country, int allcases, int death, int activecases, int recovered) {
        this.country = country;
        this.continent = continent;
        this.allcases = allcases;
        this.death = death;
        this.activecases = activecases;
        this.recovered = recovered;
    }

    //getters for the above content
    public String getContinent() {
        return continent;
    }


    public String getCountry() {
        return country;
    }


    public int getDeath() {
        return death;
    }

    public int getRecovered() {
        return recovered;
    }

    public int getAllCases() {
        return allcases;
    }

    public int getActiveCases() {
        return activecases;
    }
}
