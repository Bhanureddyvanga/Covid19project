package com.example.androidfinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class classcontiadapter extends BaseAdapter {
    ArrayList<classconti>Data;
    LayoutInflater layoutInflater;

    public classcontiadapter(ArrayList<classconti> Data, Context context) {
        this.Data = Data;
        layoutInflater = layoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return Data.size();
    }

    @Override
    public Object getItem(int i) {
        return Data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view==null){
            view = layoutInflater.inflate(R.layout.list_row,null);
            holder = new ViewHolder();
            holder.CountryName=view.findViewById(R.id.countrytext);
            holder.CountryCases=view.findViewById(R.id.casestext);
            view.setTag(holder);
        }
        else
            holder = (ViewHolder) view.getTag();
        holder.CountryName.setText(Data.get(i).getCountry());
        holder.CountryCases.setText(String.format("%d",Data.get(i).getAllCases()));
        return view;
    }
    static class ViewHolder{
        TextView CountryName;
        TextView CountryCases;

    }
}
