package com.example.androidfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class country_details extends AppCompatActivity {
    EditText allcases, active, death, recovered;
    TextView country;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_details);
        country=findViewById(R.id.countrytv);
        country.setText(MainActivity.cname);
        allcases=findViewById(R.id.allcasespt);
        allcases.setText(String.format("%d",MainActivity.ccases));
        active =findViewById(R.id.activept);
        active.setText(String.format("%d",MainActivity.curent));
        death=findViewById(R.id.deathpt);
        death.setText(String.format("%d",MainActivity.cdeath));
        recovered=findViewById(R.id.recoveredpt);
        recovered.setText(String.format("%d",MainActivity.recovered));
    }
}
